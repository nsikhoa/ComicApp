package com.example.comicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.GridView;

import com.example.comicapp.adapter.ComicAdapter;
import com.example.comicapp.object.Comic;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
GridView gdvDSTruyen;
ComicAdapter adapter;
ArrayList<Comic> comicArrayList;
EditText edtTimKiem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        anhXa();
        setUp();
        setClick();
    }
    private void init(){
        comicArrayList = new ArrayList<>();
        comicArrayList.add(new Comic("Võ Đạo Độc Tôn", "Chapter 214", "http://st.truyenchon.com/data/comics/228/vo-dao-doc-ton.jpg"));
        comicArrayList.add(new Comic("Yêu Thần Ký", "Chapter 304", "http://st.truyenchon.com/data/comics/85/yeu-than-ky.jpg"));
        comicArrayList.add(new Comic("Hoàng tử Tennis", "Chapter 361", "http://st.truyenchon.com/data/comics/229/hoang-tu-tennis.jpg"));
        comicArrayList.add(new Comic("Tây Du", "Chapter 219", "http://st.truyenchon.com/data/comics/156/tay-du.jpg"));
        comicArrayList.add(new Comic("Dị Tộc Trùng Sinh", "Chapter 142", "http://st.truyenchon.com/data/comics/80/di-toc-trung-sinh.jpg"));
        comicArrayList.add(new Comic("Mairimashita! Iruma-kun", "Chapter 182", "http://st.truyenchon.com/data/comics/113/mairimashita-iruma-kun.jpg"));

        adapter = new ComicAdapter(this,0, comicArrayList);
    }
    private void anhXa(){
        gdvDSTruyen = findViewById(R.id.gdvDSTruyen);
        edtTimKiem = findViewById(R.id.edtTimKiem);
    }
    private void setUp(){
        gdvDSTruyen.setAdapter(adapter);
    }
    private void setClick(){
        edtTimKiem.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String s = edtTimKiem.getText().toString();
                adapter.sortTruyen(s);
            }
        });
    }

}